# Design Summary

Designed by Yuehan Zhao, Min liu, Tingyu Pan and Wei Wang

## Game Mechanism

This is a old fashion RAIDEN game, the player can touch the screen to control the player-ship and 
fight with the Enemy ship.The Enemy ship include three kinds of small ship and a Big-boss-ship. 
Also, they have different kinds of attacking ways (bullet), and track of motion. Plus, we should give
the players two different award to increase the player's life and attack. Final, we mark the 
player's performance and give them a score to value it. 

## Coding Approach

We should have four different class: Award, Bullet, Enemy and Player to set the attribution of the 
different thing we want to show in our game including the attacking way, the life, the track of 
motion. Then we should have three activity - the StartActivity allow player can enter the game; the 
MainActivity show the picture of all the item in our game,the background and the different sound 
effects of different action the EndActivity show the final score and allow player to paly the game 
again. 

## UI Design

We find some picture on the website(including the bullet, the Playership, the enemy), and design the
the backgroud picture by our team member. We also design the layout of each activity to make them 
human-friendly and easy to use.